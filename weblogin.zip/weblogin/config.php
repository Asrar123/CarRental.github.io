<?php 
@mysql_connect("localhost","root")or die("con not  connnection");
@mysql_select_db("logindata");


?>