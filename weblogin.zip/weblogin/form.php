<html  lang="en" dir="ltr">
<head>
     <meta charset="utf-8">
      <title>login form  </title>
      <link rel="stylesheet" type="text/css" href="style1.css">
     
</head>
<body bgcolor="white">

      
      <form class="box" action="registration1.php" method="post">
        <h1>Login form</h1>
        <div>
                  
          <input type="text" name="user" placeholder="Username"  ><br>
          
                 
          <input type="text" name="email" placeholder="Email"  ><br>
           
          <input type="password" name="password" placeholder="password" ><br>         

          <input type="text" name="mobile" placeholder="Mobile No"  ><br>
                 
          <input type="text" name="comment" placeholder="comment"  ><br>
             
          
          <input type="submit" name="login" value="login" ><br>
        </div>
      </form>

</form>
</body>
</html>
