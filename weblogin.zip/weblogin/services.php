<!DOCTYPE html>
<html>
<head>
  <title></title>


<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" type="text/css" href="style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@200&display=swap" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<style >


 div.card {
  width: 300px;
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
  text-align: center;
  border-radius: 50px;
}
div.card-body {
  padding: 10px;
   border-radius: 50px;
}
body{

  background-color:black;
}




</style>
</head>
<body>


<section class="my-5">
        <div class="py-5">
            <h3 class="text-center text-white">Our Gallary</h3>
        </div>
       


        <div class="container-fluid">
          <div class="row">
              <div class="col-lg-4  col-md-4" col-12>
                  <div class="card">
                     <img class="card-img-top" src="images/c6.jfif" alt="Card image">
                     <div class="card-body">
                        <h4 class="card-title">Beatuful Car</h4>
                           <p class="card-text">Some example text.</p>
                          <a href="#" class="btn btn-primary">See Profile</a>
                     </div>
                  </div>
              </div><br>
       
              <div class="col-lg-4  col-md-4" col-12>
                  <div class="card">
          <img class="card-img-top" src="images/c3.jfif" alt="Card image">
                     <div class="card-body">
                        <h4 class="card-title">Beatuful Car</h4>
                           <p class="card-text">Some example text.</p>
                          <a href="#" class="btn btn-primary">See Profile</a>
                     </div>
                  </div>
                </div><br>

                <div class="col-lg-4  col-md-4" col-12>
                  <div class="card">
                      <img class="card-img-top" src="images/c4.jfif" alt="Card image">
                     <div class="card-body">
                        <h4 class="card-title">Beatuful Car</h4>
                           <p class="card-text">Some example text.</p>
                          <a href="#" class="btn btn-primary">See Profile</a>
                     </div>
                  </div>
                </div><br>
 </section>

<section class="my-5">

      <div class="container-fluid">
          <div class="row">
        
                   <div class="col-lg-4  col-md-4" col-12>
                  <div class="card">
          <img class="card-img-top" src="images/c9.jfif" alt="Card image">
                     <div class="card-body">
                        <h4 class="card-title">Beatuful Car</h4>
                           <p class="card-text">Some example text.</p>
                          <a href="#" class="btn btn-primary">See Profile</a>
                     </div>
                  </div>
                </div>

              <div class="col-lg-4  col-md-4" col-12>
                  <div class="card">
          <img class="card-img-top" src="images/c7.jfif" alt="Card image">
                     <div class="card-body">
                        <h4 class="card-title">Beatuful Car</h4>
                           <p class="card-text">Some example text.</p>
                          <a href="#" class="btn btn-primary">See Profile</a>
                     </div>
                  </div>
                </div>

              <div class="col-lg-4  col-md-4" col-12>
                  <div class="card">
          <img class="card-img-top" src="images/c2.jfif" alt="Card image">
                     <div class="card-body">
                        <h4 class="card-title">Beatuful Car</h4>
                           <p class="card-text">Some example text.</p>
                          <a href="#" class="btn btn-primary">See Profile</a>
                     </div>
                  </div>
                </div>             

          </div>
        </div>
  </section>

<section class="my-5">

      <div class="container-fluid">
          <div class="row">
        
                   <div class="col-lg-4  col-md-4" col-12>
                  <div class="card">
          <img class="card-img-top" src="images/c10.jfif" alt="Card image">
                     <div class="card-body">
                        <h4 class="card-title">Beatuful Car</h4>
                           <p class="card-text">Some example text.</p>
                          <a href="#" class="btn btn-primary">See Profile</a>
                     </div>
                  </div>
                </div>

              <div class="col-lg-4  col-md-4" col-12>
                  <div class="card">
          <img class="card-img-top" src="images/c11.jfif" alt="Card image">
                     <div class="card-body">
                        <h4 class="card-title">Beatuful Car</h4>
                           <p class="card-text">Some example text.</p>
                          <a href="#" class="btn btn-primary">See Profile</a>
                     </div>
                  </div>
                </div>

              <div class="col-lg-4  col-md-4" col-12>
                  <div class="card">
          <img class="card-img-top" src="images/c12.jfif" alt="Card image">
                     <div class="card-body">
                        <h4 class="card-title">Beatuful Car</h4>
                           <p class="card-text">Some example text.</p>
                          <a href="#" class="btn btn-primary">See Profile</a>
                     </div>
                  </div>
                </div>             

          </div>
        </div>
  </section>


         <footer>
            <p class="p-3 bg-dark text-white text-center">@AAM INDUSTRIES</p>
          </footer>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>